# PET2Print Recycler Controller
Arduino based controller for my PET2Print PET bottle recycler that turns PET bottles into 3D printing filament. Code is configured for an Arduino Uno or Arduino Pro Mini.

Visit my blog for the circuit and guide to assemble your PET2Print device and controller - https://www.the-diy-life.com/pet-bottle-recycler-part-1-using-an-arduino-uno-r4-to-control-a-3d-printers-hotend/
